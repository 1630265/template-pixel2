<?php
/**
 * @version    $Id$
 * @package    SUN Framework
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) 2012 JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */


defined('_JEXEC') or die;
function modChrome_default($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_no($module, &$params, &$attribs)
{
	if ($module->content)
	{
		echo $module->content;
	}
}

function modChrome_well($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', 'box-title'));

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="well ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<' . $headerTag . ' class="' . $headerClass . '">' . $module->title . '</' . $headerTag . '>';
			}

			echo $module->content;
		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_red($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-red ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_green($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-green ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_pink($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-pink ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_grey($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-grey ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_dark($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-dark ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_blue($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-blue ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_cyan($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-cyan ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_black($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-black ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_white($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-white ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_blank($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-blank ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_orange($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-orange ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}

function modChrome_box_yellow($module, &$params, &$attribs)
{
	$moduleTag     = $params->get('module_tag', 'div');
	$bootstrapSize = (int) $params->get('bootstrap_size', 0);
	$moduleClass   = $bootstrapSize != 0 ? ' span' . $bootstrapSize : '';
	$headerTag     = htmlspecialchars($params->get('header_tag', 'h3'));
	$headerClass   = htmlspecialchars($params->get('header_class', ''));
	$icon 			= '';
	if (preg_match('/^(.+)?(fa fa-[^\s]+)(.+)?$/', $headerClass, $match)) {
		$headerClass = $match[1];
		$icon .= $match[2];
	}

	if ($module->content)
	{
		echo '<' . $moduleTag . ' class="module-style box-yellow ' . htmlspecialchars($params->get('moduleclass_sfx')) . $moduleClass . '">';

			if ($module->showtitle)
			{
				echo '<div class="module-title"><' . $headerTag . ' class="box-title ' . $headerClass . '">';
				if ($icon != '')
				{
					echo '<i class="'. $icon .'"></i>';
				}
				echo '<span>'. $module->title . '</span></' . $headerTag . '></div>';
			}

			echo '<div class="module-body">';
				echo $module->content;
			echo "</div>";

		echo '</' . $moduleTag . '>';
	}
}