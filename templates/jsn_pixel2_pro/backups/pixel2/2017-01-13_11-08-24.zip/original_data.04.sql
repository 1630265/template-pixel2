INSERT INTO jos_tags
(`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES 
('1', '0', '0', '1', '0', '', 'ROOT', 'root', '', '', '1', '0', '0000-00-00 00:00:00', '1', '{}', '', '', '', '0', '2011-01-01 00:00:01', '', '0', '0000-00-00 00:00:00', '', '', '0', '*', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
DROP TABLE IF EXISTS `jos_template_styles`;
CREATE TABLE `jos_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_template_styles
(`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES 
('2', 'bluestork', '1', '0', 'Bluestork - Default', '{\"useRoundedCorners\":\"1\",\"showSiteName\":\"0\"}'),
('5', 'hathor', '1', '0', 'Hathor - Default', '{\"showSiteName\":\"0\",\"colourChoice\":\"\",\"boldText\":\"0\"}'),
('167', 'protostar', '0', '0', 'protostar - Default', '{\"templateColor\":\"\",\"logoFile\":\"\",\"googleFont\":\"1\",\"googleFontName\":\"Open+Sans\",\"fluidContainer\":\"0\"}'),
('168', 'isis', '1', '1', 'isis - Default', '{\"templateColor\":\"\",\"logoFile\":\"\"}'),
('169', 'beez3', '0', '0', 'beez3 - Default', '{\"wrapperSmall\":53,\"wrapperLarge\":72,\"logo\":\"\",\"sitetitle\":\"\",\"sitedescription\":\"\",\"navposition\":\"center\",\"bootstrap\":\"\",\"templatecolor\":\"nature\",\"headerImage\":\"\",\"backgroundcolor\":\"#eee\"}'),
('175', 'jsn_mobilize', '0', '0', 'JLIB_INSTALLER_DEFAULT_STYLE', '{}'),
('178', 'jsn_pixel2_pro', '0', '1', 'JSN Pixel 2 - Default', ''),
('179', 'jsn_pixel2_pro', '0', '0', 'JSN Pixel 2 - Coming soon', '');
DROP TABLE IF EXISTS `jos_ucm_base`;
CREATE TABLE `jos_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `jos_ucm_content`;
CREATE TABLE `jos_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `core_body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_urls` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_metadesc` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_language` (`core_language`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`),
  KEY `idx_alias` (`core_alias`(100)),
  KEY `idx_title` (`core_title`(100)),
  KEY `idx_content_type` (`core_type_alias`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Contains core content data in name spaced fields';
DROP TABLE IF EXISTS `jos_ucm_history`;
CREATE TABLE `jos_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `jos_update_sites`;
CREATE TABLE `jos_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Update Sites';

INSERT INTO jos_update_sites
(`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`, `extra_query`) VALUES 
('1', 'Joomla! Core', 'collection', 'https://update.joomla.org/core/sts/list_sts.xml', '1', '0', ''),
('2', 'Joomla! Extension Directory', 'collection', 'https://update.joomla.org/jed/list.xml', '1', '1484279693', ''),
('3', 'Accredited Joomla! Translations', 'collection', 'https://update.joomla.org/language/translationlist_3.xml', '1', '0', ''),
('4', 'K2 Updates', 'extension', 'http://getk2.org/update.xml', '1', '1484279693', ''),
('6', 'Kunena 4.0 Update Site', 'collection', 'http://update.kunena.org/4.0/list.xml', '1', '1484279694', ''),
('44', '', 'collection', 'http://update.joomla.org/core/list.xml', '1', '1484279694', ''),
('80', 'Joomla! Update Component Update Site', 'extension', 'https://update.joomla.org/core/extensions/com_joomlaupdate.xml', '1', '1484279694', ''),
('152', 'uniform', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_uniform.xml', '1', '1484279695', ''),
('200', 'K2 Updates', 'extension', 'http://getk2.org/app/update.xml', '1', '1484279696', ''),
('217', 'easyslider', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_easyslider.xml', '1', '1484279697', ''),
('218', 'Kunena 5.0 Update Site', 'collection', 'https://update.kunena.org/5.0/list.xml', '1', '1484279698', ''),
('223', 'mobilize', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_mobilize.xml', '1', '1484279698', ''),
('227', 'imageshow', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_imageshow.xml', '1', '1484279699', ''),
('229', 'SunFw FrameWork Updates', 'extension', 'http://www.joomlashine.com/versioning/extensions/sunfwframework.xml', '1', '1484279699', ''),
('246', 'pagebuilder', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_pagebuilder.xml', '1', '1484279700', ''),
('247', 'pagebuilder2', 'collection', 'http://rc.joomlashine.com/demo/joomla-templates/jsn_pixel_2/j30/pro/administrator/index.php?option=com_pagebuilder2&task=checkUpdate&file=update.xml', '1', '1484279704', ''),
('248', 'poweradmin', 'collection', 'http://www.joomlashine.com/versioning/extensions/com_poweradmin.xml', '1', '0', '');
DROP TABLE IF EXISTS `jos_update_sites_extensions`;
CREATE TABLE `jos_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links extensions to update sites';

INSERT INTO jos_update_sites_extensions
(`update_site_id`, `extension_id`) VALUES 
('1', '700'),
('2', '700'),
('3', '802'),
('4', '10159'),
('6', '10178'),
('44', '700'),
('80', '28'),
('152', '10146'),
('200', '10159'),
('217', '10220'),
('218', '10178'),
('223', '10192'),
('227', '10292'),
('229', '10311'),
('246', '10195'),
('247', '10324'),
('248', '10133');
DROP TABLE IF EXISTS `jos_updates`;
CREATE TABLE `jos_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `folder` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `detailsurl` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `infourl` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_query` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Available Updates';

INSERT INTO jos_updates
(`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES 
('1', '6', '0', 'Kunena Language Pack', 'Language Pack for Kunena Forum', 'pkg_kunena_languages', 'package', '', '0', '4.0.12', '', 'https://update.kunena.org/4.0/pkg_kunena_languages.xml', '', ''),
('2', '6', '0', 'Kunena Latest Module', '', 'mod_kunenalatest', 'module', '', '0', '3.1.2.1', '', 'https://update.kunena.org/4.0/mod_kunenalatest.xml', '', ''),
('3', '6', '0', 'Kunena Login Module', '', 'mod_kunenalogin', 'module', '', '0', '3.1.2', '', 'https://update.kunena.org/4.0/mod_kunenalogin.xml', '', ''),
('4', '6', '0', 'Kunena Search Module', '', 'mod_kunenasearch', 'module', '', '0', '3.1.2', '', 'https://update.kunena.org/4.0/mod_kunenasearch.xml', '', ''),
('5', '6', '0', 'Kunena Statistics Module', '', 'mod_kunenastats', 'module', '', '0', '3.1.2', '', 'https://update.kunena.org/4.0/mod_kunenastats.xml', '', ''),
('6', '6', '0', 'Content - Kunena Discuss', '', 'kunenadiscuss', 'plugin', 'content', '0', '3.1.2', '', 'https://update.kunena.org/4.0/plg_content_kunenadiscuss.xml', '', ''),
('7', '6', '0', 'Search - Kunena', '', 'kunena', 'plugin', 'search', '0', '3.1.2', '', 'https://update.kunena.org/4.0/plg_search_kunena.xml', '', ''),
('8', '152', '10146', 'JSN UniForm', '', 'com_uniform', 'component', '', '1', '4.0.6', '', '', '', ''),
('9', '218', '10178', 'Kunena Forum', 'Kunena Forum', 'pkg_kunena', 'package', '', '0', '5.0.5', '', 'https://update.kunena.org/5.0/pkg_kunena.xml', '', ''),
('10', '218', '0', 'Kunena Language Pack', 'Language Pack for Kunena Forum', 'pkg_kunena_languages', 'package', '', '0', '5.0.5', '', 'https://update.kunena.org/5.0/pkg_kunena_languages.xml', '', ''),
('11', '218', '0', 'Kunena Latest Module', '', 'mod_kunenalatest', 'module', '', '0', '5.0.2', '', 'https://update.kunena.org/5.0/mod_kunenalatest.xml', '', ''),
('12', '218', '0', 'Kunena Login Module', '', 'mod_kunenalogin', 'module', '', '0', '5.0.2', '', 'https://update.kunena.org/5.0/mod_kunenalogin.xml', '', ''),
('13', '218', '0', 'Kunena Search Module', '', 'mod_kunenasearch', 'module', '', '0', '5.0.2', '', 'https://update.kunena.org/5.0/mod_kunenasearch.xml', '', ''),
('14', '218', '0', 'Kunena Statistics Module', '', 'mod_kunenastats', 'module', '', '0', '5.0.2', '', 'https://update.kunena.org/5.0/mod_kunenastats.xml', '', ''),
('15', '218', '0', 'Content - Kunena Discuss', '', 'kunenadiscuss', 'plugin', 'content', '0', '5.0.2', '', 'https://update.kunena.org/5.0/plg_content_kunenadiscuss.xml', '', ''),
('16', '218', '0', 'Search - Kunena', '', 'kunena', 'plugin', 'search', '0', '5.0.2', '', 'https://update.kunena.org/5.0/plg_search_kunena.xml', '', ''),
('17', '223', '10192', 'JSN Mobilize', '', 'com_mobilize', 'component', '', '1', '1.2.2', '', '', '', ''),
('18', '227', '10292', 'JSN ImageShow', '', 'com_imageshow', 'component', '', '1', '5.0.4', '', '', '', ''),
('21', '246', '10195', 'JSN PageBuilder', '', 'com_pagebuilder', 'component', '', '1', '1.3.6', '', '', '', '');
DROP TABLE IF EXISTS `jos_user_keys`;
CREATE TABLE `jos_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `series` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uastring` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_user_keys
(`id`, `user_id`, `token`, `series`, `invalid`, `time`, `uastring`) VALUES 
('1', 'demoadmin', '$2y$10$qYsv2/ORd1c.Doo3IK.P4udTj6rshzK.h0Hi1fqUQpTJxzQi389T2', '2HBeCQbebd3z5QPr9Vkw', '0', '1440208352', 'ecfd3c53582f34330da5cb93b6142261');
DROP TABLE IF EXISTS `jos_user_notes`;
CREATE TABLE `jos_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `body` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `jos_user_profiles`;
CREATE TABLE `jos_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Simple user profile storage table';
DROP TABLE IF EXISTS `jos_user_usergroup_map`;
CREATE TABLE `jos_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_user_usergroup_map
(`user_id`, `group_id`) VALUES 
('42', '8'),
('43', '7');
DROP TABLE IF EXISTS `jos_usergroups`;
CREATE TABLE `jos_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_usergroups
(`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES 
('1', '0', '1', '20', 'Public'),
('2', '1', '6', '17', 'Registered'),
('3', '2', '7', '14', 'Author'),
('4', '3', '8', '11', 'Editor'),
('5', '4', '9', '10', 'Publisher'),
('6', '1', '2', '5', 'Manager'),
('7', '6', '3', '4', 'Administrator'),
('8', '1', '18', '19', 'Super Users'),
('10', '3', '12', '13', 'Shop Suppliers'),
('12', '2', '15', '16', 'Customer Group');
DROP TABLE IF EXISTS `jos_users`;
CREATE TABLE `jos_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login',
  PRIMARY KEY (`id`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `idx_name` (`name`(100))
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_users
(`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`, `requireReset`) VALUES 
('42', 'Super User', 'demoadmin', 'example.admin@joomlashine.com', '$2y$10$F17Rn5b4dqDXSTARghQvf.ouSN/Aa5k11ushGk/CYt025jpR.31mm', '0', '1', '2011-04-01 02:22:19', '2017-01-13 03:54:48', '', '{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"none\",\"helpsite\":\"\",\"timezone\":\"\"}', '0000-00-00 00:00:00', '0', '', '', '0'),
('43', 'democontent', 'democontent', 'example.content@joomlashine.com', '59b02140887d3671d47727b514dbda88', '0', '1', '2012-04-11 10:56:28', '2013-09-25 07:51:10', '', '{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"tinymce\",\"helpsite\":\"\",\"timezone\":\"\"}', '0000-00-00 00:00:00', '0', '', '', '0');
DROP TABLE IF EXISTS `jos_utf8_conversion`;
CREATE TABLE `jos_utf8_conversion` (
  `converted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_utf8_conversion
(`converted`) VALUES 
('2');
DROP TABLE IF EXISTS `jos_viewlevels`;
CREATE TABLE `jos_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO jos_viewlevels
(`id`, `title`, `ordering`, `rules`) VALUES 
('1', 'Public', '0', '[1]'),
('2', 'Registered', '1', '[6,2,8]'),
('3', 'Special', '2', '[6,3,8]'),
('4', 'Customer Access Level', '3', '[6,3,12]');